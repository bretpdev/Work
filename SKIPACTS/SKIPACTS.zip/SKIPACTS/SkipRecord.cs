﻿namespace SKIPACTS
{
    public class SkipRecord
    {
        public string Ssn { get; set; }
        public string ActivityCode { get; set; }
        public string Comment { get; set; }
        public string ActivityType { get; set; }
    }
}